const usersElement = document.getElementById('users');

async function fetchUsers() {
  
}

fetchUsers();
